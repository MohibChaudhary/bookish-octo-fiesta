import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Menu, X } from "lucide-react";

const links = [
  { to: "/program", label: "Coaching" },
  { to: "/speaking", label: "Keynote Speaking" },
  { to: "/podcast", label: "Podcast" },
  { to: "/resources", label: "Resources" },
  { to: "/about", label: "About" },
];

export function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
  }, [open]);

  const solid = scrolled || open;

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-500 bg-ink ${
        solid ? "shadow-[0_10px_30px_-20px_rgba(0,0,0,0.6)] border-b border-white/5" : "border-b border-transparent"
      }`}
    >
      <div className="container-editorial flex items-center justify-between h-[84px]">
        <Link to="/" className="flex items-center gap-3 group" onClick={() => setOpen(false)}>
          <span className="logo-bubble transition-transform group-hover:-rotate-6">M</span>
          <span className="hidden sm:flex flex-col leading-none">
            <span className="font-serif text-[15px] text-ivory tracking-tight">Maria Malik</span>
            <span className="mt-1 text-[10px] tracking-[0.28em] uppercase text-ivory/55">The Introverted Speaker</span>
          </span>
        </Link>

        <nav className="hidden lg:flex items-center gap-10">
          {links.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              className="nav-link text-ivory/75 hover:text-ivory transition-colors link-underline"
              activeProps={{ className: "text-ivory" }}
            >
              {l.label}
            </Link>
          ))}
          <Link to="/contact" className="btn-primary !py-3 !px-6 !text-[11px]">
            Book Maria
          </Link>
        </nav>

        <button
          className="lg:hidden p-2 -mr-2 text-ivory"
          aria-label={open ? "Close menu" : "Open menu"}
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {open && (
        <div className="lg:hidden bg-ink border-t border-white/5">
          <div className="container-editorial py-10 flex flex-col gap-6">
            {links.map((l) => (
              <Link
                key={l.to}
                to={l.to}
                onClick={() => setOpen(false)}
                className="font-serif text-3xl text-ivory"
              >
                {l.label}
              </Link>
            ))}
            <Link
              to="/contact"
              onClick={() => setOpen(false)}
              className="btn-primary mt-4 self-start"
            >
              Book Maria
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}
