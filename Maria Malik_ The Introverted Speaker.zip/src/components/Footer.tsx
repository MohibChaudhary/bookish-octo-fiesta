import { Link } from "@tanstack/react-router";
import { Linkedin, Youtube, Mic } from "lucide-react";
import { SoundWave } from "./SoundWave";

export function Footer() {
  return (
    <footer className="bg-ink text-ivory">
      <div className="container-editorial py-20">
        <div className="grid gap-12 md:grid-cols-[1.4fr_1fr_1fr_1.2fr]">
          <div>
            <p className="font-serif text-2xl leading-tight">The Introverted Speaker</p>
            <p className="mt-4 text-sm text-ivory/60 max-w-xs">
              Executive speaking coaching for introverted leaders. Quiet power, spoken clearly.
            </p>
            <div className="mt-6 text-terracotta">
              <SoundWave bars={38} />
            </div>
          </div>

          <div>
            <p className="eyebrow text-ivory/50 mb-4">Explore</p>
            <ul className="space-y-3 text-sm">
              <li><Link to="/about" className="hover:text-terracotta transition-colors">About Maria</Link></li>
              <li><Link to="/program" className="hover:text-terracotta transition-colors">The Accelerator</Link></li>
              <li><Link to="/speaking" className="hover:text-terracotta transition-colors">Speaking</Link></li>
              <li><Link to="/podcast" className="hover:text-terracotta transition-colors">Podcast</Link></li>
              <li><Link to="/resources" className="hover:text-terracotta transition-colors">Resources</Link></li>
            </ul>
          </div>

          <div>
            <p className="eyebrow text-ivory/50 mb-4">Elsewhere</p>
            <ul className="space-y-3 text-sm">
              <li><a href="#" className="inline-flex items-center gap-2 hover:text-terracotta"><Linkedin size={15}/> LinkedIn</a></li>
              <li><a href="#" className="inline-flex items-center gap-2 hover:text-terracotta"><Youtube size={15}/> YouTube</a></li>
              <li><a href="#" className="inline-flex items-center gap-2 hover:text-terracotta"><Mic size={15}/> Podcast</a></li>
            </ul>
          </div>

          <div>
            <p className="eyebrow text-ivory/50 mb-4">Quiet notes, monthly</p>
            <p className="text-sm text-ivory/70 mb-4">One essay a month on presence, voice, and being taken seriously. No funnels.</p>
            <form className="flex gap-2" onSubmit={(e) => e.preventDefault()}>
              <input
                type="email"
                required
                placeholder="you@work.com"
                className="flex-1 bg-transparent border-b border-ivory/30 focus:border-terracotta outline-none py-2 text-sm placeholder:text-ivory/40"
              />
              <button className="text-sm text-terracotta hover:text-ivory transition-colors">Subscribe →</button>
            </form>
          </div>
        </div>

        <div className="mt-16 pt-8 border-t border-ivory/10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 text-xs text-ivory/50">
          <p>© {new Date().getFullYear()} Maria Malik · The Introverted Speaker</p>
          <div className="flex gap-6">
            <a href="#" className="hover:text-ivory">Privacy</a>
            <a href="#" className="hover:text-ivory">Terms</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
