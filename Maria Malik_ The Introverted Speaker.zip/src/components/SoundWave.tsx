interface Props {
  bars?: number;
  className?: string;
  color?: string;
  animated?: boolean;
}

export function SoundWave({ bars = 48, className = "", color = "currentColor", animated = true }: Props) {
  return (
    <div className={`flex items-center gap-[3px] h-6 ${className}`} aria-hidden="true">
      {Array.from({ length: bars }).map((_, i) => {
        const h = 20 + Math.sin(i * 0.55) * 60 + Math.cos(i * 0.31) * 25;
        const height = Math.max(8, Math.min(100, h));
        return (
          <span
            key={i}
            className="inline-block w-[2px] rounded-full origin-center"
            style={{
              height: `${height}%`,
              background: color,
              animation: animated ? `wave ${1.4 + (i % 5) * 0.15}s ease-in-out ${i * 0.03}s infinite` : undefined,
            }}
          />
        );
      })}
    </div>
  );
}
