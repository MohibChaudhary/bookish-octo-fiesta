import { createFileRoute, Link } from "@tanstack/react-router";
import aboutAsset from "../assets/maria-about.jpg.asset.json";
import { Reveal } from "../components/Reveal";

const aboutImg = aboutAsset.url;

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About Maria Malik — The Introverted Speaker" },
      { name: "description", content: "The story behind The Introverted Speaker: eleven years of being the quiet one in the room, and the method Maria Malik built from it." },
      { property: "og:title", content: "About Maria Malik" },
      { property: "og:description", content: "The story and method behind The Introverted Speaker." },
      { property: "og:url", content: "/about" },
    ],
    links: [{ rel: "canonical", href: "/about" }],
  }),
  component: About,
});

const timeline = [
  { y: "2012", t: "First promotion, first freeze", d: "Named director at 27. Delivered a promotion I'd earned to a room that kept looking past me." },
  { y: "2015", t: "The turning point", d: "Coached under two speech pathologists and a Harvard-trained rhetoric professor. The pieces started to fit." },
  { y: "2019", t: "The practice begins", d: "Left executive role to coach full-time. First cohort of nine introverted directors." },
  { y: "2022", t: "The podcast launches", d: "The Introverted Speaker podcast — quiet conversations on being taken seriously — releases its first season." },
  { y: "2024", t: "250th client", d: "Coached leaders now sit on boards, run divisions, and give keynotes they once refused." },
  { y: "2026", t: "Where we are now", d: "A small, deliberate practice. One accelerator cohort at a time. A handful of keynote engagements a year." },
];

function About() {
  return (
    <>
      <section className="pt-40 pb-20">
        <div className="container-editorial max-w-4xl">
          <Reveal>
            <p className="eyebrow">About</p>
            <h1 className="mt-6 font-serif text-5xl md:text-7xl leading-[1] text-ink">
              I was the quietest person in every room I belonged in.
            </h1>
            <p className="mt-8 text-xl text-ink/70 max-w-2xl leading-relaxed">
              Maria Malik is an executive speaking coach for introverted leaders. She works privately with directors, senior managers, and executives at companies like [Google], [Stripe], [Bank of America], and [Genentech].
            </p>
          </Reveal>
        </div>
      </section>

      <section className="pb-28">
        <div className="container-editorial">
          <Reveal>
            <img src={aboutImg} alt="Maria Malik" className="w-full max-h-[70vh] object-cover" loading="lazy" width={1408} height={1600} />
          </Reveal>
        </div>
      </section>

      <section className="pb-28 md:pb-40">
        <div className="container-editorial grid lg:grid-cols-[1fr_1.4fr] gap-16">
          <Reveal>
            <p className="eyebrow">Her story</p>
          </Reveal>
          <Reveal delay={100} className="space-y-6 text-lg text-ink/75 leading-relaxed">
            <p>
              For eleven years I was the person who had the right answer forty-five minutes after the meeting ended. Technically strong. Chronically overlooked. Watched three louder colleagues get promoted past me before someone finally said out loud what I already suspected — that the work wasn't the problem.
            </p>
            <p>
              I read every book. I took the improv class. I did the "power poses" and the "just speak up" affirmations. None of it stuck, because none of it was mine.
            </p>
            <p>
              What eventually worked was smaller and more specific: a set of vocal, verbal, and structural moves I could practice like scales. The version of me that earned the promotion at 34 wasn't louder than the one at 27. She just stopped translating herself into someone else's dialect.
            </p>
            <p className="font-serif text-3xl text-ink leading-snug pt-4">
              This is the coaching I wish someone had built for me.
            </p>
          </Reveal>
        </div>
      </section>

      <section className="py-28 md:py-36 bg-cream">
        <div className="container-editorial">
          <Reveal>
            <p className="eyebrow">Timeline</p>
            <h2 className="mt-6 font-serif text-4xl md:text-5xl text-ink">A slow, deliberate practice.</h2>
          </Reveal>

          <ol className="mt-16 relative border-l border-border ml-3">
            {timeline.map((item, i) => (
              <Reveal as="li" key={item.y} delay={i * 80} className="pl-10 pb-14 relative">
                <span className="absolute -left-[7px] top-1 w-3 h-3 rounded-full bg-terracotta ring-4 ring-cream" />
                <p className="eyebrow">{item.y}</p>
                <h3 className="font-serif text-2xl md:text-3xl text-ink mt-2">{item.t}</h3>
                <p className="mt-3 text-ink/70 max-w-2xl">{item.d}</p>
              </Reveal>
            ))}
          </ol>
        </div>
      </section>

      <section className="py-28 md:py-36">
        <div className="container-editorial max-w-2xl text-center">
          <Reveal>
            <h2 className="font-serif text-4xl md:text-6xl text-ink leading-[1.05]">Want to talk?</h2>
            <p className="mt-6 text-ink/70 text-lg">Thirty minutes. Real conversation. Zero funnel.</p>
            <Link to="/contact" className="btn-primary mt-8 inline-flex">Book a discovery call</Link>
          </Reveal>
        </div>
      </section>
    </>
  );
}
