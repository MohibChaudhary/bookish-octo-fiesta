import { createFileRoute } from "@tanstack/react-router";
import { Download, ArrowRight } from "lucide-react";
import speakingAsset from "../assets/maria-hero.jpg.asset.json";
import { Reveal } from "../components/Reveal";

const speakingImg = speakingAsset.url;

export const Route = createFileRoute("/speaking")({
  head: () => ({
    meta: [
      { title: "Speaking & Keynotes — Maria Malik" },
      { name: "description", content: "Book Maria Malik for keynotes on executive presence for introverts, leadership communication, and being taken seriously." },
      { property: "og:title", content: "Book Maria Malik to Speak" },
      { property: "og:description", content: "Keynotes and workshops on quiet leadership and executive presence." },
      { property: "og:url", content: "/speaking" },
    ],
    links: [{ rel: "canonical", href: "/speaking" }],
  }),
  component: Speaking,
});

const topics = [
  { t: "The Quiet Third", d: "Executive presence for the thirty percent of your leaders who don't self-promote — and why they're the ones you're about to lose." },
  { t: "Composure Under Pressure", d: "A practical, physiological, and structural framework for leading rooms when the stakes are high and the questions get hard." },
  { t: "Rewriting the Meeting", d: "What actually causes senior meetings to overrun introverted voices — and the small structural changes that fix it in a quarter." },
];

const stages = ["SXSW", "TEDx Boston", "Google Women's Summit", "Sequoia Leadership", "The Wharton Club", "Adobe Summit", "AICPA Engage", "Deloitte D.Live"];

function Speaking() {
  return (
    <>
      <section className="pt-40 pb-16 md:pb-24">
        <div className="container-editorial grid lg:grid-cols-[1.1fr_1fr] gap-14 items-center">
          <Reveal>
            <p className="eyebrow">For Event Organizers</p>
            <h1 className="mt-6 font-serif text-5xl md:text-7xl leading-[0.98] text-ink">
              Book Maria for your next leadership stage.
            </h1>
            <p className="mt-8 text-lg text-ink/70 max-w-xl leading-relaxed">
              Keynotes, half-day workshops, fireside conversations. Especially good for leadership summits, women-in-tech tracks, and internal executive offsites.
            </p>
            <div className="mt-10 flex flex-wrap gap-4">
              <a href="#book" className="btn-primary">Check availability <ArrowRight size={16} /></a>
              <a href="#" className="btn-outline"><Download size={14} /> Download the media kit</a>
            </div>
          </Reveal>
          <Reveal delay={150}>
            <img src={speakingImg} alt="Maria Malik on stage" className="w-full aspect-[4/3] object-cover" loading="lazy" width={1600} height={1104} />
          </Reveal>
        </div>
      </section>

      <section className="py-24 md:py-32 bg-cream">
        <div className="container-editorial">
          <Reveal>
            <p className="eyebrow">Signature Talks</p>
            <h2 className="mt-6 font-serif text-4xl md:text-6xl text-ink max-w-3xl">Three talks. All tailored to your audience.</h2>
          </Reveal>
          <div className="mt-14 grid md:grid-cols-3 gap-6">
            {topics.map((t, i) => (
              <Reveal key={t.t} delay={i * 100} className="bg-ivory p-10 border border-border h-full flex flex-col">
                <p className="font-serif text-6xl text-terracotta">0{i + 1}</p>
                <h3 className="mt-6 font-serif text-2xl text-ink">{t.t}</h3>
                <p className="mt-4 text-ink/70 leading-relaxed flex-1">{t.d}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 md:py-32">
        <div className="container-editorial">
          <Reveal className="max-w-2xl">
            <p className="eyebrow">Past stages</p>
            <h2 className="mt-6 font-serif text-4xl md:text-5xl text-ink">A partial list, in Maria's real voice: some of these were terrifying.</h2>
          </Reveal>
          <div className="mt-12 flex flex-wrap gap-x-10 gap-y-4 font-serif text-2xl md:text-3xl text-ink/60">
            {stages.map((s) => (
              <span key={s} className="hover:text-terracotta transition-colors">{s}</span>
            ))}
          </div>
        </div>
      </section>

      <section id="book" className="py-24 md:py-32 bg-ink text-ivory">
        <div className="container-editorial max-w-2xl">
          <p className="eyebrow text-terracotta">Booking Request</p>
          <h2 className="mt-6 font-serif text-4xl md:text-5xl">Tell us about your event.</h2>
          <form className="mt-12 space-y-8" onSubmit={(e) => { e.preventDefault(); alert("Thanks — we'll be in touch within two business days."); }}>
            {[
              { l: "Your name", n: "name", t: "text" },
              { l: "Organization", n: "org", t: "text" },
              { l: "Work email", n: "email", t: "email" },
              { l: "Event date", n: "date", t: "text", ph: "Approximate is fine" },
              { l: "Audience size", n: "size", t: "text" },
            ].map((f) => (
              <label key={f.n} className="block">
                <span className="text-xs tracking-[0.2em] uppercase text-ivory/50">{f.l}</span>
                <input
                  required
                  type={f.t}
                  name={f.n}
                  placeholder={f.ph}
                  className="mt-2 w-full bg-transparent border-b border-ivory/25 focus:border-terracotta outline-none py-3 text-lg placeholder:text-ivory/30"
                />
              </label>
            ))}
            <label className="block">
              <span className="text-xs tracking-[0.2em] uppercase text-ivory/50">A sentence about the audience</span>
              <textarea rows={4} required className="mt-2 w-full bg-transparent border-b border-ivory/25 focus:border-terracotta outline-none py-3 text-lg" />
            </label>
            <button className="btn-primary bg-terracotta hover:bg-ivory hover:text-ink">Send request <ArrowRight size={16} /></button>
          </form>
        </div>
      </section>
    </>
  );
}
