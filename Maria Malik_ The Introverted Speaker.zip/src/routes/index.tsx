import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Play, Quote } from "lucide-react";
import heroAsset from "../assets/maria-hero.jpg.asset.json";
import aboutAsset from "../assets/maria-about.jpg.asset.json";
import { SoundWave } from "../components/SoundWave";
import { Reveal } from "../components/Reveal";
import { CountUp } from "../components/CountUp";

const heroImg = heroAsset.url;
const aboutImg = aboutAsset.url;
const speakingImg = heroAsset.url;

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Maria Malik — Executive Speaking Coach for Introverted Leaders" },
      { name: "description", content: "Executive communication coaching for introverted leaders. Speak with clarity, command respect, and get promoted faster — without pretending to be extroverted." },
      { property: "og:title", content: "The Introverted Speaker — Maria Malik" },
      { property: "og:description", content: "Executive speaking coaching for introverted leaders. Trusted by 350+ professionals across tech, healthcare, consulting, and enterprise." },
      { property: "og:image", content: heroAsset.url },
      { property: "og:url", content: "/" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:image", content: heroAsset.url },
    ],
    links: [{ rel: "canonical", href: "/" }],
  }),
  component: Index,
});

const featuredIn = ["Forbes", "HBR", "Fast Company", "Inc.", "Bloomberg", "LinkedIn News"];

const testimonials = [
  {
    quote:
      "This has been a year full of wins. My largest was being promoted into the role of VP, Strategic Finance at one of the largest health systems in the US.",
    name: "Sean Murray",
    title: "VP, Strategic Finance — promoted within 6 months",
  },
  {
    quote:
      "I got a promotion. My bosses know I've been taking your course; they actually said I feel like another person after the course. It is that obvious.",
    name: "Connie Chiu",
    title: "Promoted within 3 months",
  },
  {
    quote:
      "I just interviewed for and GOT my dream job. As an awkward introvert who's stumbled through so many interviews, learning from Maria helped renew my hope and gave me the tools I needed.",
    name: "Julie Hersum",
    title: "Landed dream job",
  },
];

function Index() {
  return (
    <>
      {/* ============ HERO — editorial split, real portrait ============ */}
      <section className="relative bg-ink text-ivory overflow-hidden pt-32 md:pt-36">
        {/* Faint cyan glow */}
        <div className="pointer-events-none absolute -top-40 -right-40 w-[520px] h-[520px] rounded-full bg-terracotta/15 blur-[120px]" />
        <div className="pointer-events-none absolute top-1/3 -left-32 w-[380px] h-[380px] rounded-full bg-terracotta/10 blur-[120px]" />

        <div className="relative container-editorial grid lg:grid-cols-[1.1fr_1fr] gap-14 lg:gap-20 items-center pb-24 md:pb-32">
          <div className="animate-rise">
            <div className="flex items-center gap-3">
              <span className="h-px w-10 bg-terracotta" />
              <p className="eyebrow !text-terracotta">Executive Speaking Coach</p>
            </div>
            <h1 className="mt-8 font-serif text-[clamp(2.7rem,6.4vw,5.8rem)] leading-[0.98] text-ivory">
              Executive communication<br />
              for <span className="italic rule-accent">introverted leaders.</span>
            </h1>
            <p className="mt-9 text-lg md:text-xl text-ivory/75 max-w-xl leading-relaxed">
              Speak with clarity. Command respect. Get promoted faster without pretending to be extroverted. Trusted by 350+ professionals and senior leaders across tech, healthcare, consulting, and enterprise.
            </p>

            <div className="mt-11 flex flex-wrap gap-4 items-center">
              <Link to="/contact" className="btn-primary">
                Apply for coaching <ArrowRight size={16} />
              </Link>
              <Link to="/program" className="btn-outline text-ivory">
                <Play size={13} /> Explore programs
              </Link>
            </div>

            <div className="mt-14 flex items-center gap-4 text-terracotta">
              <SoundWave bars={44} />
              <span className="text-[11px] tracking-[0.28em] uppercase text-ivory/50">Quiet power, spoken clearly</span>
            </div>
          </div>

          <Reveal delay={200} className="relative">
            <div className="relative aspect-[4/5] overflow-hidden rounded-[4px]">
              <img
                src={heroImg}
                alt="Maria Malik, executive speaking coach and founder of The Introverted Speaker"
                className="h-full w-full object-cover"
                width={1600}
                height={2000}
              />
              {/* corner brackets */}
              <span className="absolute top-3 left-3 w-6 h-6 border-t border-l border-terracotta" />
              <span className="absolute top-3 right-3 w-6 h-6 border-t border-r border-terracotta" />
              <span className="absolute bottom-3 left-3 w-6 h-6 border-b border-l border-terracotta" />
              <span className="absolute bottom-3 right-3 w-6 h-6 border-b border-r border-terracotta" />
            </div>
            <div className="absolute -bottom-8 -left-6 md:-left-10 bg-terracotta text-ink p-6 max-w-[280px] rounded-tr-3xl rounded-br-3xl rounded-tl-3xl">
              <Quote size={18} />
              <p className="mt-3 font-serif text-xl leading-snug">
                When you communicate like a leader, people treat you like one.
              </p>
              <p className="mt-3 text-[10px] tracking-[0.28em] uppercase font-semibold">— Maria Malik</p>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ============ TRUST BAR ============ */}
      <section className="bg-ink text-ivory border-t border-white/5">
        <div className="container-editorial py-8 flex flex-col lg:flex-row items-center gap-6 lg:gap-12 text-sm text-ivory/60">
          <p className="whitespace-nowrap"><span className="text-terracotta font-medium">350+</span> leaders coached · <span className="text-terracotta font-medium">250K+</span> community</p>
          <span className="hidden lg:block w-px h-4 bg-white/15" />
          <p className="whitespace-nowrap tracking-[0.2em] uppercase text-[11px] text-ivory/40">As featured in</p>
          <div className="flex flex-wrap items-center gap-x-10 gap-y-3 justify-center font-serif text-ivory/70">
            {featuredIn.map((f) => (
              <span key={f} className="text-xl tracking-tight hover:text-terracotta transition-colors cursor-default">{f}</span>
            ))}
          </div>
        </div>
      </section>

      {/* ============ PROBLEM / EMPATHY ============ */}
      <section className="py-28 md:py-40 bg-cream">
        <div className="container-editorial max-w-3xl">
          <Reveal>
            <p className="eyebrow">If any of this is familiar</p>
          </Reveal>
          <Reveal delay={80}>
            <h2 className="mt-6 font-serif text-4xl md:text-6xl leading-[1.05] text-ink">
              You've done the work. You still get talked over.
            </h2>
          </Reveal>
          <Reveal delay={160}>
            <div className="mt-10 space-y-6 text-lg leading-relaxed text-ink/75">
              <p>
                You draft the memo three times before you send it. You rehearse the update in the shower. In the meeting itself, someone with half your prep speaks first, and the room moves on.
              </p>
              <p>
                You're not underqualified. You're underestimated. There's a difference and the fix isn't turning into someone else.
              </p>
              <p>
                This is coaching for the version of you that already exists. The one who thinks clearly, prepares carefully, and cares about being right more than being heard. We keep all of that. We just make sure the room hears it.
              </p>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ============ ABOUT SHORT ============ */}
      <section className="py-28 md:py-36">
        <div className="container-editorial grid lg:grid-cols-[1fr_1.1fr] gap-16 items-center">
          <Reveal className="relative order-2 lg:order-1">
            <img
              src={aboutImg}
              alt="Maria Malik in a coaching session"
              className="w-full aspect-[4/5] object-cover"
              loading="lazy"
              width={1408}
              height={1600}
            />
            <div className="absolute top-6 -right-4 md:-right-8 bg-ink text-ivory p-6 max-w-[220px]">
              <Quote size={20} className="text-terracotta" />
              <p className="mt-3 font-serif text-lg leading-snug">
                I spent eleven years being the quietest person in every room I belonged in.
              </p>
            </div>
          </Reveal>

          <Reveal delay={120} className="order-1 lg:order-2">
            <p className="eyebrow">About Maria</p>
            <h2 className="mt-6 font-serif text-4xl md:text-5xl text-ink leading-[1.05]">
              Hi, I'm Maria Malik.
            </h2>
            <div className="mt-8 space-y-5 text-ink/75 text-lg leading-relaxed">
              <p>
                I'm an Executive Speaking Expert and founder of The Introverted Speaker. I help introverted leaders sound calm, clear, and authoritative in high-stakes moments&nbsp; meetings, presentations, interviews, and promotions.
              </p>
              <p>
                I've coached <strong className="text-ink">350+ leaders</strong>, built a community of <strong className="text-ink">250,000+ professionals</strong>, and helped clients earn promotions, land VP and Director roles, secure raises, and lead meetings with authority.
              </p>
              <p className="text-ink/60 italic">
                Originally from Pakistan and raised in Canada.
              </p>
            </div>
            <Link to="/about" className="btn-outline mt-10">Read Maria's story</Link>
          </Reveal>
        </div>
      </section>

      {/* ============ PROGRAM ============ */}
      <section id="watch" className="py-28 md:py-40 bg-ink text-ivory">
        <div className="container-editorial">
          <div className="grid lg:grid-cols-[1fr_1.2fr] gap-12 items-end mb-16">
            <Reveal>
              <p className="eyebrow text-terracotta">Signature Program</p>
              <h2 className="mt-6 font-serif text-5xl md:text-7xl leading-[0.98]">
                The Executive Voice Accelerator
              </h2>
            </Reveal>
            <Reveal delay={120}>
              <p className="text-lg text-ivory/70 leading-relaxed max-w-xl">
                Three months. One-to-one and small group. A private method for sounding calm, clear, respected, and powerful under pressure&nbsp; without pretending to be extroverted.
              </p>
            </Reveal>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-px bg-ivory/10">
            {[
              { n: "01", t: "Presence", d: "Audit your default patterns — vocal, physical, verbal. Replace the tells that undersell your seniority." },
              { n: "02", t: "Language", d: "Executive phrasing under pressure. How to disagree, decide, and defer without shrinking." },
              { n: "03", t: "The Room", d: "Meetings, panels, boardrooms. How to enter, hold, and close the space you're already in." },
              { n: "04", t: "The Stage", d: "Keynotes and high-visibility moments. Preparation, delivery, and recovery when it doesn't go to plan." },
            ].map((m, i) => (
              <Reveal key={m.n} delay={i * 100} className="bg-ink p-10 hover:bg-ivory/[0.03] transition-colors">
                <p className="eyebrow text-terracotta">Module {m.n}</p>
                <h3 className="mt-5 font-serif text-3xl">{m.t}</h3>
                <p className="mt-4 text-sm text-ivory/60 leading-relaxed">{m.d}</p>
              </Reveal>
            ))}
          </div>

          <div className="mt-16 flex flex-wrap gap-4">
            <Link to="/program" className="btn-primary bg-terracotta hover:bg-ivory hover:text-ink">
              Apply for the Accelerator <ArrowRight size={16} />
            </Link>
            <Link to="/program" className="btn-outline border-ivory/40 text-ivory hover:bg-ivory hover:text-ink">
              See the full curriculum
            </Link>
          </div>
        </div>
      </section>

      {/* ============ RESULTS / STATS ============ */}
      <section className="py-28 md:py-36">
        <div className="container-editorial">
          <Reveal className="max-w-2xl">
            <p className="eyebrow">Results</p>
            <h2 className="mt-6 font-serif text-4xl md:text-6xl text-ink leading-[1.05]">
              What quiet leaders build when the room finally listens.
            </h2>
          </Reveal>

          <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-y-10 gap-x-6 border-y border-border py-14">
            {[
              { n: 350, s: "+", l: "Leaders coached" },
              { n: 250, s: "K+", l: "Community following" },
              { n: 90, s: " day", l: "Flagship program" },
              { n: 3, s: "×", l: "Promotions (single client)" },
            ].map((s, i) => (
              <Reveal key={s.l} delay={i * 90}>
                <p className="font-serif text-6xl md:text-7xl text-ink">
                  <CountUp to={s.n} suffix={s.s} />
                </p>
                <p className="mt-2 text-sm tracking-wide text-ink/60">{s.l}</p>
              </Reveal>
            ))}
          </div>

          {/* Testimonials */}
          <div className="mt-20 grid md:grid-cols-3 gap-8">
            {testimonials.map((t, i) => (
              <Reveal key={i} delay={i * 120} className="bg-cream p-10 flex flex-col">
                <Quote size={22} className="text-terracotta" />
                <p className="mt-6 font-serif text-2xl leading-snug text-ink flex-1">"{t.quote}"</p>
                <div className="mt-8 pt-6 border-t border-border">
                  <p className="text-sm font-medium text-ink">{t.name}</p>
                  <p className="text-xs text-ink/60 mt-1">{t.title}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ============ SPEAKING TEASER ============ */}
      <section className="py-28 md:py-36 bg-blush/60">
        <div className="container-editorial grid lg:grid-cols-2 gap-14 items-center">
          <Reveal>
            <img src={speakingImg} alt="Maria on stage" className="w-full aspect-[4/3] object-cover" loading="lazy" width={1600} height={1104} />
          </Reveal>
          <Reveal delay={120}>
            <p className="eyebrow">For Event Organizers</p>
            <h2 className="mt-6 font-serif text-4xl md:text-5xl leading-tight text-ink">
              A keynote for the quiet third of your leadership team.
            </h2>
            <p className="mt-6 text-ink/75 text-lg leading-relaxed">
              Maria speaks at leadership offsites, industry summits, and internal ERGs on executive presence for introverts, communicating under pressure, and building rooms where thoughtful people can lead.
            </p>
            <Link to="/speaking" className="btn-primary mt-8">
              Book Maria to speak <ArrowRight size={16} />
            </Link>
          </Reveal>
        </div>
      </section>

      {/* ============ CTA ============ */}
      <section className="py-32 md:py-44 bg-ivory">
        <div className="container-editorial max-w-3xl text-center">
          <Reveal>
            <p className="eyebrow">The next step is small</p>
            <h2 className="mt-6 font-serif text-5xl md:text-7xl leading-[1] text-ink">
              A thirty-minute conversation.<br />No pitch. No pressure.
            </h2>
            <p className="mt-8 text-lg text-ink/70 max-w-xl mx-auto">
              Tell me the room you keep losing. I'll tell you honestly whether this is the right work and if it isn't, where to look instead.
            </p>
            <Link to="/contact" className="btn-primary mt-10 inline-flex">
              Book a discovery call <ArrowRight size={16} />
            </Link>
          </Reveal>
        </div>
      </section>
    </>
  );
}
