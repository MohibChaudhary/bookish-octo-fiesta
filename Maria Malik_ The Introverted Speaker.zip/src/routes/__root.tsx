import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { Nav } from "../components/Nav";
import { Footer } from "../components/Footer";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-ivory px-6">
      <div className="max-w-md text-center">
        <p className="eyebrow">404</p>
        <h1 className="mt-4 font-serif text-5xl text-ink">This page has gone quiet.</h1>
        <p className="mt-4 text-muted-foreground">The page you're looking for isn't here — but the conversation continues.</p>
        <Link to="/" className="btn-primary mt-8 inline-flex">Return home</Link>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-ivory px-6">
      <div className="max-w-md text-center">
        <h1 className="font-serif text-3xl text-ink">Something interrupted the page.</h1>
        <p className="mt-3 text-sm text-muted-foreground">Try again, or head back to safer ground.</p>
        <div className="mt-6 flex flex-wrap justify-center gap-3">
          <button onClick={() => { router.invalidate(); reset(); }} className="btn-primary">Try again</button>
          <a href="/" className="btn-outline">Go home</a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "The Introverted Speaker — Executive Speaking Coaching by Maria Malik" },
      { name: "description", content: "Executive speaking coaching for introverted leaders. Speak with clarity, command respect, get promoted faster without pretending to be extroverted." },
      { name: "author", content: "Maria Malik" },
      { name: "theme-color", content: "#F7F3EC" },
      { property: "og:site_name", content: "The Introverted Speaker" },
      { property: "og:title", content: "The Introverted Speaker — Executive Speaking Coaching by Maria Malik" },
      { property: "og:description", content: "Executive speaking coaching for introverted leaders. Speak with clarity, command respect, get promoted faster without pretending to be extroverted." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "The Introverted Speaker — Executive Speaking Coaching by Maria Malik" },
      { name: "twitter:description", content: "Executive speaking coaching for introverted leaders. Speak with clarity, command respect, get promoted faster without pretending to be extroverted." },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/4277620b-f8b2-4dde-a0b8-ab57aaf8625c/id-preview-2fea8622--dd011d04-ef3d-4049-a715-1b952f010d6d.lovable.app-1782918104658.png" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/4277620b-f8b2-4dde-a0b8-ab57aaf8625c/id-preview-2fea8622--dd011d04-ef3d-4049-a715-1b952f010d6d.lovable.app-1782918104658.png" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "icon", href: "/favicon.ico", type: "image/x-icon" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,300;9..144,400;9..144,500;9..144,600&family=Inter:wght@400;500;600&display=swap" },
    ],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Person",
          name: "Maria Malik",
          jobTitle: "Executive Speaking Coach",
          brand: "The Introverted Speaker",
          description: "Executive speaking coaching for introverted leaders.",
          sameAs: [],
        }),
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  return (
    <QueryClientProvider client={queryClient}>
      <Nav />
      <main>
        <Outlet />
      </main>
      <Footer />
    </QueryClientProvider>
  );
}
