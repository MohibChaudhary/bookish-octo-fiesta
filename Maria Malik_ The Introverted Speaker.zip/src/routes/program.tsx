import { createFileRoute, Link } from "@tanstack/react-router";
import { Check, X } from "lucide-react";
import { Reveal } from "../components/Reveal";

export const Route = createFileRoute("/program")({
  head: () => ({
    meta: [
      { title: "The Executive Voice Accelerator — Maria Malik" },
      { name: "description", content: "A three-month private coaching program for introverted directors and executives who want to be heard, respected, and promoted." },
      { property: "og:title", content: "The Executive Voice Accelerator" },
      { property: "og:description", content: "Three months of executive communication coaching for introverted leaders." },
      { property: "og:url", content: "/program" },
    ],
    links: [{ rel: "canonical", href: "/program" }],
  }),
  component: Program,
});

const modules = [
  { n: "01", t: "Presence Diagnostic", d: "A recorded audit of your current speaking patterns — vocal, physical, verbal. We name the specific micro-behaviors that undersell your seniority.", items: ["90-minute recorded diagnostic", "Written pattern report", "Baseline metrics we'll retest at week 12"] },
  { n: "02", t: "Executive Language", d: "The phrasing library senior leaders actually use to disagree, decide, and defer. Repeatable, not memorized.", items: ["Executive phrase bank", "Live pressure-practice sessions", "Debrief on your real weekly meetings"] },
  { n: "03", t: "Owning the Room", d: "Standing meetings, panels, boardrooms. How to enter, hold, and close the space you're already in.", items: ["Meeting choreography", "Interrupt-recovery drills", "One-on-one prep for a real high-stakes meeting"] },
  { n: "04", t: "The Stage", d: "Keynotes, all-hands, and high-visibility moments. A repeatable prep-and-delivery system.", items: ["Talk architecture", "On-camera delivery coaching", "One rehearsed talk of your choice"] },
];

function Program() {
  return (
    <>
      <section className="pt-40 pb-28 md:pb-36">
        <div className="container-editorial max-w-5xl">
          <Reveal>
            <p className="eyebrow">Signature Program · 3 Months · By Application</p>
            <h1 className="mt-6 font-serif text-5xl md:text-8xl leading-[0.95] text-ink">
              The Executive<br />Voice <span className="text-terracotta">Accelerator</span>.
            </h1>
            <p className="mt-8 text-xl text-ink/70 max-w-2xl leading-relaxed">
              A twelve-week private practice for introverted directors and executives. Sound calm, clear, respected, and powerful under pressure — without pretending to be someone you're not.
            </p>
            <div className="mt-10 flex flex-wrap gap-4">
              <Link to="/contact" className="btn-primary">Apply for the next cohort</Link>
              <a href="#curriculum" className="btn-outline">See the curriculum</a>
            </div>
          </Reveal>

          <div className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-x-6 gap-y-8 border-y border-border py-10">
            {[
              ["Format", "1:1 + intimate group"],
              ["Length", "12 weeks"],
              ["Cadence", "Weekly, 60–90 min"],
              ["Cohort size", "8 leaders, max"],
            ].map(([k, v]) => (
              <div key={k}>
                <p className="eyebrow text-ink/50">{k}</p>
                <p className="mt-2 font-serif text-2xl text-ink">{v}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="curriculum" className="py-24 md:py-32 bg-cream">
        <div className="container-editorial">
          <Reveal>
            <p className="eyebrow">The Curriculum</p>
            <h2 className="mt-6 font-serif text-4xl md:text-6xl text-ink max-w-3xl">Four modules. Twelve weeks. One version of you the room can't ignore.</h2>
          </Reveal>

          <div className="mt-16 grid md:grid-cols-2 gap-6">
            {modules.map((m, i) => (
              <Reveal key={m.n} delay={i * 100} className="bg-ivory p-10 border border-border">
                <div className="flex items-baseline justify-between">
                  <p className="eyebrow text-terracotta">Module {m.n}</p>
                </div>
                <h3 className="mt-4 font-serif text-3xl md:text-4xl text-ink">{m.t}</h3>
                <p className="mt-4 text-ink/70 leading-relaxed">{m.d}</p>
                <ul className="mt-6 space-y-2">
                  {m.items.map((it) => (
                    <li key={it} className="flex gap-3 text-sm text-ink/80">
                      <Check size={16} className="text-terracotta mt-0.5 shrink-0" /> {it}
                    </li>
                  ))}
                </ul>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="py-28 md:py-36">
        <div className="container-editorial grid md:grid-cols-2 gap-12">
          <Reveal className="bg-blush/50 p-10 md:p-14">
            <p className="eyebrow">Who this is for</p>
            <ul className="mt-6 space-y-4 text-lg text-ink/80">
              {["Directors and senior managers eyeing VP", "Executives who present to boards or 300+ audiences", "High performers who leave meetings replaying what they should've said", "Leaders whose LinkedIn writing lands but whose voice doesn't yet"].map((x) => (
                <li key={x} className="flex gap-3"><Check size={18} className="text-terracotta mt-1.5 shrink-0" /> {x}</li>
              ))}
            </ul>
          </Reveal>
          <Reveal delay={120} className="bg-ink text-ivory p-10 md:p-14">
            <p className="eyebrow text-terracotta">Who this isn't for</p>
            <ul className="mt-6 space-y-4 text-lg text-ivory/80">
              {["Anyone looking for a personality transplant", "Leaders unwilling to record themselves", "Sales-stage confidence hacks or motivational content", "People early in their career — this is senior-level work"].map((x) => (
                <li key={x} className="flex gap-3"><X size={18} className="text-terracotta mt-1.5 shrink-0" /> {x}</li>
              ))}
            </ul>
          </Reveal>
        </div>
      </section>

      <section className="py-28 md:py-36 bg-cream">
        <div className="container-editorial max-w-3xl text-center">
          <Reveal>
            <p className="eyebrow">Investment</p>
            <p className="mt-6 font-serif text-3xl md:text-4xl text-ink leading-tight">
              Priced for senior leaders and the companies that sponsor them. Full pricing shared on the discovery call. Payment plans and invoicing available.
            </p>
            <Link to="/contact" className="btn-primary mt-10 inline-flex">Apply for the Accelerator</Link>
          </Reveal>
        </div>
      </section>
    </>
  );
}
