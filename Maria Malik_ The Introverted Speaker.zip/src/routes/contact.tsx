import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Calendar, Mail, Clock, ArrowRight, Check } from "lucide-react";
import { Reveal } from "../components/Reveal";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Book a Discovery Call — Maria Malik" },
      { name: "description", content: "Book a free 30-minute discovery call with Maria Malik to talk about executive speaking coaching." },
      { property: "og:title", content: "Book a Discovery Call" },
      { property: "og:description", content: "Thirty minutes. No pitch. No pressure." },
      { property: "og:url", content: "/contact" },
    ],
    links: [{ rel: "canonical", href: "/contact" }],
  }),
  component: Contact,
});

function Contact() {
  const [sent, setSent] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const submit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const errs: Record<string, string> = {};
    if (!fd.get("name")) errs.name = "Your name, please.";
    const email = String(fd.get("email") ?? "");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errs.email = "A working email address.";
    if (!fd.get("message")) errs.message = "One or two sentences is enough.";
    setErrors(errs);
    if (Object.keys(errs).length === 0) setSent(true);
  };

  return (
    <>
      <section className="pt-40 pb-16">
        <div className="container-editorial max-w-4xl">
          <Reveal>
            <p className="eyebrow">Discovery Call · 30 min · Free</p>
            <h1 className="mt-6 font-serif text-5xl md:text-7xl leading-[0.98] text-ink">
              Let's have a real conversation.
            </h1>
            <p className="mt-8 text-lg text-ink/70 max-w-2xl">
              Tell me the room you keep losing. I'll tell you honestly whether the Accelerator is the right work — and if it isn't, where I'd point you instead.
            </p>
          </Reveal>
        </div>
      </section>

      <section className="pb-24">
        <div className="container-editorial grid lg:grid-cols-[1.2fr_1fr] gap-10">
          {/* Calendar embed placeholder */}
          <Reveal className="bg-cream p-2 border border-border min-h-[540px] flex flex-col">
            <div className="flex items-center gap-3 px-6 pt-6">
              <Calendar size={18} className="text-terracotta" />
              <p className="eyebrow">Pick a time</p>
            </div>
            <div className="flex-1 flex items-center justify-center p-10">
              <div className="text-center max-w-md">
                <p className="font-serif text-3xl text-ink leading-tight">Live calendar embed appears here.</p>
                <p className="mt-4 text-sm text-ink/60">Drop your Calendly / Cal.com link into <code className="text-terracotta">/contact</code> and the widget slots in — no template look required.</p>
                <a href="#" className="btn-primary mt-8 inline-flex">Open Maria's calendar <ArrowRight size={16} /></a>
              </div>
            </div>
          </Reveal>

          {/* Contact form */}
          <Reveal delay={120} className="bg-ink text-ivory p-8 md:p-10">
            <p className="eyebrow text-terracotta">Prefer to write first?</p>
            <h2 className="mt-3 font-serif text-3xl">Send a note.</h2>

            {sent ? (
              <div className="mt-10 flex flex-col items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-terracotta/20 text-terracotta flex items-center justify-center">
                  <Check size={22} />
                </div>
                <p className="font-serif text-2xl leading-snug">Thanks — I read every one of these. You'll hear back within two business days.</p>
              </div>
            ) : (
              <form onSubmit={submit} noValidate className="mt-8 space-y-6">
                {(["name", "email"] as const).map((f) => (
                  <label key={f} className="block">
                    <span className="text-xs tracking-[0.2em] uppercase text-ivory/50">{f === "name" ? "Your name" : "Work email"}</span>
                    <input
                      name={f}
                      type={f === "email" ? "email" : "text"}
                      className={`mt-2 w-full bg-transparent border-b outline-none py-3 ${errors[f] ? "border-terracotta" : "border-ivory/25 focus:border-terracotta"}`}
                    />
                    {errors[f] && <span className="text-terracotta text-xs mt-1 block">{errors[f]}</span>}
                  </label>
                ))}
                <label className="block">
                  <span className="text-xs tracking-[0.2em] uppercase text-ivory/50">The room you keep losing</span>
                  <textarea
                    name="message"
                    rows={5}
                    className={`mt-2 w-full bg-transparent border-b outline-none py-3 ${errors.message ? "border-terracotta" : "border-ivory/25 focus:border-terracotta"}`}
                  />
                  {errors.message && <span className="text-terracotta text-xs mt-1 block">{errors.message}</span>}
                </label>
                <button type="submit" className="btn-primary bg-terracotta hover:bg-ivory hover:text-ink">
                  Send the note <ArrowRight size={16} />
                </button>
              </form>
            )}
          </Reveal>
        </div>
      </section>

      <section className="pb-32">
        <div className="container-editorial grid md:grid-cols-3 gap-6 text-ink/70">
          {[
            { i: <Mail size={18} className="text-terracotta" />, l: "Direct email", v: "hello@theintrovertedspeaker.com" },
            { i: <Clock size={18} className="text-terracotta" />, l: "Response time", v: "Within 2 business days" },
            { i: <Calendar size={18} className="text-terracotta" />, l: "Based in", v: "New York · works globally" },
          ].map((x) => (
            <div key={x.l} className="border-t border-border pt-6">
              {x.i}
              <p className="eyebrow mt-3">{x.l}</p>
              <p className="mt-2 font-serif text-xl text-ink">{x.v}</p>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}
