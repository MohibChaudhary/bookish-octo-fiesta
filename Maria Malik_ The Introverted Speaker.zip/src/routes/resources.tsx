import { createFileRoute } from "@tanstack/react-router";
import { ArrowUpRight, Download } from "lucide-react";
import { Reveal } from "../components/Reveal";

export const Route = createFileRoute("/resources")({
  head: () => ({
    meta: [
      { title: "Essays & Resources — The Introverted Speaker" },
      { name: "description", content: "Essays on executive presence, quiet leadership, and being taken seriously — plus a free Executive Presence Checklist." },
      { property: "og:title", content: "Resources — The Introverted Speaker" },
      { property: "og:description", content: "Long-form essays on presence, voice, and quiet leadership." },
      { property: "og:url", content: "/resources" },
    ],
    links: [{ rel: "canonical", href: "/resources" }],
  }),
  component: Resources,
});

const essays = [
  { c: "The Workplace", t: "An Introvert's Guide to Surviving the Workplace", r: "12 min read", d: "The specific meeting habits, communication systems, and boundaries that let quiet people lead well without burning out." },
  { c: "Presence", t: "The Introvert's Guide to Executive Presence", r: "9 min read", d: "Executive presence isn't extroversion. It's a set of vocal, verbal, and structural moves anyone can learn — and introverts often master faster." },
  { c: "Promotion", t: "Why You Keep Getting Passed Over (And What Actually Fixes It)", r: "11 min read", d: "The three specific patterns that cost overlooked leaders promotions, in order of how easy they are to fix." },
  { c: "Meetings", t: "How to Say the Thing Before Someone Louder Says It", r: "7 min read", d: "A repeatable structural move for the moment right before you speak." },
  { c: "Delivery", t: "What to Do in Your Body Ninety Seconds Before a Keynote", r: "8 min read", d: "A short physiological routine for the moment when your nervous system decides this is a threat." },
  { c: "Career", t: "The Case Against 'Just Being More Confident'", r: "6 min read", d: "Why confidence advice fails introverted leaders — and what to build instead." },
];

function Resources() {
  return (
    <>
      <section className="pt-40 pb-20">
        <div className="container-editorial max-w-4xl">
          <Reveal>
            <p className="eyebrow">Essays & Resources</p>
            <h1 className="mt-6 font-serif text-5xl md:text-7xl leading-[0.98] text-ink">Long-form essays for quiet leaders.</h1>
            <p className="mt-8 text-lg text-ink/70 max-w-2xl">
              A slow-moving library. New pieces roughly monthly, often adapted from Maria's LinkedIn writing and podcast conversations.
            </p>
          </Reveal>
        </div>
      </section>

      {/* Lead magnet */}
      <section className="pb-24">
        <div className="container-editorial">
          <Reveal className="bg-ink text-ivory p-10 md:p-16 grid md:grid-cols-[1.4fr_1fr] gap-10 items-center">
            <div>
              <p className="eyebrow text-terracotta">Free download</p>
              <h2 className="mt-4 font-serif text-4xl md:text-5xl leading-tight">The Executive Presence Checklist.</h2>
              <p className="mt-4 text-ivory/70 max-w-lg">A twelve-page PDF: the specific vocal, verbal, and structural moves I audit for in every new client's first two weeks.</p>
            </div>
            <form onSubmit={(e) => { e.preventDefault(); alert("Check your inbox."); }} className="flex flex-col gap-3">
              <input type="email" required placeholder="Your work email" className="bg-transparent border-b border-ivory/25 focus:border-terracotta outline-none py-3 placeholder:text-ivory/40" />
              <button className="btn-primary bg-terracotta hover:bg-ivory hover:text-ink self-start"><Download size={16} /> Send me the checklist</button>
            </form>
          </Reveal>
        </div>
      </section>

      <section className="py-24 md:py-32 bg-cream">
        <div className="container-editorial">
          <div className="grid md:grid-cols-2 gap-x-10 gap-y-16">
            {essays.map((e, i) => (
              <Reveal as="article" key={e.t} delay={(i % 2) * 100} className="group cursor-pointer">
                <p className="eyebrow">{e.c} · {e.r}</p>
                <h3 className="mt-4 font-serif text-3xl md:text-4xl text-ink leading-[1.08] group-hover:text-terracotta transition-colors">
                  {e.t}
                </h3>
                <p className="mt-4 text-ink/70 leading-relaxed">{e.d}</p>
                <span className="mt-6 inline-flex items-center gap-2 text-sm text-ink link-underline">
                  Read the essay <ArrowUpRight size={16} />
                </span>
              </Reveal>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
