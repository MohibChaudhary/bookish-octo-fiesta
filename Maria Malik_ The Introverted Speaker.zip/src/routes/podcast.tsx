import { createFileRoute } from "@tanstack/react-router";
import { Headphones, Youtube, ArrowUpRight } from "lucide-react";
import podcastAsset from "../assets/maria-about.jpg.asset.json";
import { SoundWave } from "../components/SoundWave";
import { Reveal } from "../components/Reveal";

const podcastImg = podcastAsset.url;

export const Route = createFileRoute("/podcast")({
  head: () => ({
    meta: [
      { title: "The Introverted Speaker Podcast — Maria Malik" },
      { name: "description", content: "Quiet conversations on presence, voice, and being taken seriously. Listen and watch The Introverted Speaker." },
      { property: "og:title", content: "The Introverted Speaker Podcast" },
      { property: "og:description", content: "Quiet conversations on presence and voice. New episodes weekly." },
      { property: "og:url", content: "/podcast" },
    ],
    links: [{ rel: "canonical", href: "/podcast" }],
  }),
  component: Podcast,
});

const startHere = [
  { n: "042", t: "Why the smartest person in the room stays quiet", len: "38 min" },
  { n: "029", t: "Executive presence isn't a personality. It's a practice.", len: "44 min" },
  { n: "011", t: "The five phrases that stop you being interrupted", len: "27 min" },
];

const episodes = [
  { n: "046", t: "On being 'too diplomatic' — and how to stop apologizing for nuance", len: "41 min" },
  { n: "045", t: "The introvert's guide to negotiating your promotion", len: "36 min" },
  { n: "044", t: "What actually happens in your body before a keynote", len: "29 min" },
  { n: "043", t: "Why LinkedIn writing feels safe and speaking doesn't", len: "33 min" },
  { n: "042", t: "Why the smartest person in the room stays quiet", len: "38 min" },
  { n: "041", t: "A conversation with [Guest Name], CTO", len: "52 min" },
];

function Podcast() {
  return (
    <>
      <section className="pt-40 pb-20">
        <div className="container-editorial grid lg:grid-cols-[1fr_1fr] gap-14 items-center">
          <Reveal>
            <p className="eyebrow">Weekly · Season 3</p>
            <h1 className="mt-6 font-serif text-5xl md:text-7xl leading-[0.98] text-ink">
              The Introverted Speaker Podcast.
            </h1>
            <p className="mt-8 text-lg text-ink/70 max-w-lg leading-relaxed">
              Thirty-minute conversations for people who lead well and speak reluctantly. New episodes most Tuesdays.
            </p>
            <div className="mt-8 text-terracotta">
              <SoundWave bars={64} />
            </div>
            <div className="mt-10 flex flex-wrap gap-4">
              <a href="#" className="btn-primary"><Headphones size={16} /> Listen on Apple</a>
              <a href="#" className="btn-outline">Spotify</a>
              <a href="#" className="btn-outline"><Youtube size={16} /> YouTube</a>
            </div>
          </Reveal>
          <Reveal delay={150}>
            <img src={podcastImg} alt="Podcast microphone still life" className="w-full aspect-[4/3] object-cover" loading="lazy" width={1400} height={1000} />
          </Reveal>
        </div>
      </section>

      <section className="py-24 md:py-32 bg-cream">
        <div className="container-editorial">
          <Reveal>
            <p className="eyebrow">Start here</p>
            <h2 className="mt-6 font-serif text-4xl md:text-5xl text-ink">Three episodes new listeners return to.</h2>
          </Reveal>
          <div className="mt-14 grid md:grid-cols-3 gap-6">
            {startHere.map((e, i) => (
              <Reveal key={e.n} delay={i * 100} className="bg-ivory p-8 border border-border group cursor-pointer">
                <div className="flex items-baseline justify-between">
                  <p className="eyebrow text-terracotta">Ep. {e.n}</p>
                  <span className="text-xs text-ink/50">{e.len}</span>
                </div>
                <h3 className="mt-5 font-serif text-2xl text-ink leading-snug">{e.t}</h3>
                <div className="mt-8 flex items-center justify-between">
                  <span className="text-sm text-ink/70">Listen</span>
                  <ArrowUpRight size={18} className="text-terracotta group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 md:py-32">
        <div className="container-editorial">
          <div className="flex items-baseline justify-between border-b border-border pb-8">
            <h2 className="font-serif text-3xl md:text-4xl text-ink">All episodes</h2>
            <a href="#" className="text-sm text-terracotta link-underline">Full archive →</a>
          </div>
          <ul className="divide-y divide-border">
            {episodes.map((e) => (
              <Reveal as="li" key={e.n + e.t} className="grid grid-cols-[60px_1fr_auto_auto] items-center gap-6 py-6 group cursor-pointer">
                <span className="font-serif text-xl text-ink/40">{e.n}</span>
                <p className="font-serif text-lg md:text-xl text-ink group-hover:text-terracotta transition-colors">{e.t}</p>
                <span className="text-sm text-ink/50 hidden md:inline">{e.len}</span>
                <ArrowUpRight size={18} className="text-ink/50 group-hover:text-terracotta group-hover:translate-x-1 group-hover:-translate-y-1 transition-all" />
              </Reveal>
            ))}
          </ul>
        </div>
      </section>

      <section className="py-24 md:py-32 bg-ink text-ivory">
        <div className="container-editorial max-w-2xl text-center">
          <Reveal>
            <SoundWave bars={80} className="mx-auto text-terracotta" />
            <h2 className="mt-8 font-serif text-4xl md:text-6xl leading-tight">Never miss an episode.</h2>
            <p className="mt-6 text-ivory/70 text-lg">Follow on Apple, Spotify, or YouTube — or get the one-line episode note by email.</p>
            <form className="mt-10 flex gap-3 max-w-md mx-auto" onSubmit={(e) => e.preventDefault()}>
              <input type="email" required placeholder="you@work.com" className="flex-1 bg-transparent border-b border-ivory/25 focus:border-terracotta outline-none py-3 placeholder:text-ivory/40" />
              <button className="btn-primary bg-terracotta hover:bg-ivory hover:text-ink">Subscribe</button>
            </form>
          </Reveal>
        </div>
      </section>
    </>
  );
}
